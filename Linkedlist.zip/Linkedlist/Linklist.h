#include "Node.h"

class LinkList
{
    public:
    Node *head;

    //constructor
    LinkList();

    //destructor
    ~LinkList();

    //insert function
    void insertData(int data);

    //length of node function
	void nodeLength();

    //middle node function
    void middleNode();

    //remove duplicates function
    void removeDuplicates();

    //merging sorted node function 
    Node *mergeSortednodes(Node *first,Node *last);

    //delete function definition
    void deleteList();

    //traverse function definition
    void traverse();

};