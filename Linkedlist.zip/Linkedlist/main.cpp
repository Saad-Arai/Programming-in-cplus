#include "Linklist.h"

int main()
{
    int data = 0, flag = 0;
    LinkList *l1 = new LinkList();
    LinkList *l2 = new LinkList();

    do
    {
        std::cout << "Enter the options that you want. " << std::endl;
        std::cout << "- Press (1) for insert a node in LinkList. " << std::endl;
        std::cout << "- Press (2) for find length of nodes. " << std::endl;
        std::cout << "- Press (3) for find middle nodes. " << std::endl;
        std::cout << "- Press (4) for remove duplicate nodes. " << std::endl;
        std::cout << "- Press (5) for merge sorted nodes. " << std::endl;
        std::cout << "- Press (6) for delete list. " << std::endl;
        std::cout << "- Press (7) for traversing. " << std::endl;
        std::cout << "- Press (0) to exit. " << std::endl;
        std::cin >> flag;
        std::cout << "----------------------------------------------" << std::endl;

        switch (flag)
        {
        case 1:
            //for inserting
            std::cout << "Enter the nodes : ";
            std::cin >> data;
            l1->insertData(data);
            break;

        case 2:
            //for node length
            l1->nodeLength();
            break;

        case 3:
            //for middle node
            l1->middleNode();
            break;

        case 4:
            //for remove duplicates
            l1->removeDuplicates();
            break;

        case 5:
            //for mergesorted nodes
            std::cout << "Enter first node : ";
            std::cin >> data;
            std::cout << "Enter second node : ";
            std::cin >> data;
            std::cout << std::endl;
            l1->mergeSortednodes(l1->head, l2->head);
            break;

        case 6:
            //for deletion of list
            l1->deleteList();
            break;

        case 7:
            //for traverse definition
            l1->traverse();
            break;

            default:
            break;
        }
    } while (flag != 0);
    {
        std::cout<<"-------------------THANK YOU------------------"<<std::endl;
    }
    return 0;
}