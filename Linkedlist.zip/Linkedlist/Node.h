#ifndef NODE_H
#define NODE_H
#include <iostream>

class Node
{
  public:
    int data;
    Node *next;

    //paramatrize constructor
    Node(int data);

    //destructor
    ~Node();
};
#endif