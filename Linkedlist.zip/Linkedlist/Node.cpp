#include "Node.h"

//paramatrize constructor
Node ::Node(int data)
{
    this->data = data;
    next = NULL;
}

//destructor
Node ::~Node()
{
    delete next;
}