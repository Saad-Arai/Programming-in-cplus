#include "Linklist.h"

//default constructor
LinkList ::LinkList()
{
    head = NULL;
}

//insert function definition
void LinkList ::insertData(int data)
{
    Node *temp = new Node(data);
    if (head == NULL)
    {
        head = temp;
    }
    else
    {
        Node *current = head;
        while (current->next != NULL)
        {
            current = current->next;
        }
        current->next = temp;
    }
    std::cout << "----------------------------------------------" << std::endl;
    std::cout << std::endl;
}

//length of node function definition
void LinkList ::nodeLength()
{
    int length = 0;
    Node *temp = head;

    while (temp != NULL)
    {
        length++;
        temp = temp->next;
    }
    std::cout << "The Length of the given Node is : " << length << std::endl;
    std::cout << "----------------------------------------------" << std::endl;
    std::cout << std::endl;
}

//middle of a node function definition
void LinkList ::middleNode()
{
    Node *temp1 = head;
    Node *temp2 = head;

    if (head != NULL)
    {
        while (temp2 != NULL && temp2->next != NULL)
        {
            temp2 = temp2->next->next;
            temp1 = temp1->next;
        }
        std::cout << "The middle node is : " << temp1->data << std::endl;
        std::cout << "----------------------------------------------" << std::endl;
        std::cout << std::endl;
    }
}

//remove duplicates function definition
void LinkList ::removeDuplicates()
{
    if (head == NULL)
    {
        std::cout << "The List is empty. " << std::endl;
    }
    Node *current = head;
    Node *temp;

    while (current->next != NULL)
    {
        if (current->data == current->next->data)
        {
            temp = current->next->next;
            current->next = NULL;
            current->next = temp;
        }
        else
        {
            current = current->next;
        }
    }
    std::cout << "Successfully remove duplicates. " << std::endl;
    std::cout << "----------------------------------------------" << std::endl;
    std::cout << std::endl;
}

//merging sorted node Function definition
Node *LinkList ::mergeSortednodes(Node *first, Node *last)
{
    Node *temp1 = new Node(0);
    Node *temp2 = temp1;

    while (1)
    {
        if (first == NULL)
        {
            temp2->next = last;
            break;
        }
        if (last == NULL)
        {
            temp2->next = first;
            break;
        }
        if (first->data <= last->data)
        {
            temp2->next = first;
            first = first->next;
        }
        else
        {
            temp2->next = last;
            last = last->next;
        }

        temp2 = temp2->next;
    }
    return temp1->next;
}

//Delete Function definition
void LinkList ::deleteList()
{
    if (head == NULL)
    {
        std::cout << "The list empty : ";
    }
    else
    {
        head = NULL;
        std::cout << "The list is deleted. " << std::endl;
        std::cout << "----------------------------------------------" << std::endl;
        std::cout << std::endl;
    }
}

//traverse function definition
void LinkList ::traverse()
{
    Node *curr = head;
    if (head == NULL)
    {
        std::cout << "The list is empty. " << std::endl;
    }

    while (curr != NULL)
    {
        std ::cout << curr->data;
        curr = curr->next;
    }
    std::cout << std::endl;
    std::cout << "----------------------------------------------" << std::endl;
}

//destructor
LinkList ::~LinkList()
{
}