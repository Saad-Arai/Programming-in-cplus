#include "Programes.h"

int main()
{
    //variable decleration
    int size = 0, flag = 0, result = 0;
    int *arr;

    //creating a class object
    Programes p1;

    //input the size of the array;
    std::cout << "Enter the size of an array : ";
    std::cin >> size;
    std::cout << "----------------------------------------------" << std::endl;

    do
    {
        //Menu Selection
        std::cout << "Press (1) for creating an array. " << std::endl;
        std::cout << "Press (2) for inserting an array. " << std::endl;
        std::cout << "Press (3) for deletion of an array. " << std::endl;
        std::cout << "Press (4) for linear search of an array. " << std::endl;
        std::cout << "Press (5) for Binary search of an array. " << std::endl;
        std::cout << "Press (0) for exit. " << std::endl;
        std::cin >> flag;
        std::cout << "----------------------------------------------" << std::endl;
        switch (flag)
        {

        case 1:

            //calling a member function using pointer object
            arr = p1.createArray(size);
            std::cout << "----------------------------------------------" << std::endl;
            break;

        case 2:

            //calling a insertion function
            p1.insertArray(size);
            break;

        case 3:

            //calling a delete function
            p1.deleteArray(size);
            break;

        case 4:

            //calling a linearsearch function
            result = p1.linearSearch(size);
            std::cout << "----------------------------------------------" << std::endl;
            if (result == -1)
                std::cout << "Element not found in the array. " << std::endl;
            else
                std::cout << "Element found in the array at " << result << " position. " << std::endl;
            std::cout << "----------------------------------------------" << std::endl;
            break;

        case 5:

            //calling a binarysearch function
            result = p1.binarySearch(size);
            std::cout << "----------------------------------------------" << std::endl;
            if (result == -1)
                std::cout << "Element not found in the array. " << std::endl;
            else
                std::cout << "Element found in the array at " << result << " position. " << std::endl;
            std::cout << "----------------------------------------------" << std::endl;
            break;

        default:
            break;
        }
    }

    while (flag != 0);
    {
        std::cout << "Times up Run code again dood. " << std::endl;
    }
    return 0;
}