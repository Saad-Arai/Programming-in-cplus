#include "Programes.h"

//default constructor
Programes ::Programes()
{
    size = 0;
    index = 0;
    value = 0;
}

//creating array function definition
int *Programes ::createArray(int size)
{
    //using dynamic memory allocation
    int *arr = new int[size];
    for (int i = 0; i < size; ++i)
    {
        std::cout << "Enter array for index [" << i << "] : ";
        std::cin >> arr[i];
    }
    std::cout << "----------------------------------------------" << std::endl;
    for (int i = 0; i < size; ++i)
    {
        std::cout << "The Result of array after creation at index [" << i << "] : " << arr[i] << std::endl;
    }
    return arr;
}

//inserting an array function definition
void Programes ::insertArray(int size)
{
    int i = 0, index = 0, value = 0;
    int *arr;

    //for data enter
    std::cout << "Enter data for insertion function. " << std::endl;

    for (i = 0; i < size; ++i)
    {
        std::cout << "Enter array for index [" << i << "] : ";
        std::cin >> arr[i];
    }

    std::cout << "Enter the value you want to insert : ";
    std::cin >> value;
    std::cout << "Enter the index where you to insert a value : ";
    std::cin >> index;
    std::cout << std::endl;

    //insertion logic
    for (i = size; i > index; --i)
    {
        arr[i] = arr[i - 1];
    }

    arr[index] = value;

    for (i = 0; i < size + 1; ++i)
    {
        std::cout << "After insertion the value at position [" << i << "] is : " << arr[i] << std::endl;
    }
    std::cout << "----------------------------------------------" << std::endl;
}

//deletion af an array function definition
void Programes ::deleteArray(int size)
{
    int i = 0, position = 1;
    int *arr;
    //for data enter
    for (int i = 0; i < size; ++i)
    {
        std::cout << "Enter the number for array : ";
        std::cin >> arr[i];
    }
    std::cout << "Enter the position you want to delete : ";
    std::cin >> position;

    //deletion logic
    if (position >= size + 1)
    {
        std::cout << "-----Not possible-----" << std::endl;
        std::cout << "----------------------------------------------" << std::endl;
    }
    else
    {
        for (i = position - 1; i < size - 1; i++)
            arr[i] = arr[i + 1];
        std::cout << "----------------------------------------------" << std::endl;
        for (i = 0; i < size - 1; i++)
            std::cout << "The result after deletion is : " << arr[i] << std::endl;
        std::cout << "----------------------------------------------" << std::endl;
    }
}

//linear search of array function definition
int Programes ::linearSearch(int size)
{
    int i = 0, element = 0;
    int *arr;
    //for data enter
    std::cout << "Enter data for Linear search function. " << std::endl;

    for (i = 0; i < size; ++i)
    {
        std::cout << "Enter array for index [" << i << "] : ";
        std::cin >> arr[i];
    }
    std::cout << "Enter the value that you want to search : ";
    std::cin >> element;
    //linear search logic
    for (i = 0; i < size; ++i)
    {
        if (arr[i] == element)
            return i;
    }
    return -1;
}

//linear search of array function definition
int Programes ::binarySearch(int size)
{
    int i = 0, left = 0, right = size - 1, element = 0;
    int *arr;
    //for data enter
    std::cout << "Enter data for Binary search function. " << std::endl;

    for (i = 0; i < size; ++i)
    {
        std::cout << "Enter array for index [" << i << "] : ";
        std::cin >> arr[i];
    }
    std::cout << "Enter the value that you want to search : ";
    std::cin >> element;
    //binary search
    while (left <= right)
    {
        int mid = (left + right) / 2;
        if (arr[mid] == element)
            return mid;
        else if (arr[mid] < element)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1;
}

//default destructor
Programes ::~Programes()
{
}