#ifndef PROGRAMES_H
#define PROGRAMES_H
//Header Files
#include <iostream>

//Create a class
class Programes
{
    //public members define
  public:
    int size;
    int index;
    int value;

    //constructor
    Programes();

    //destructor
    ~Programes();

    //function for array creation using dynamic pointer to call function with its base address
    int *createArray(int size);

    //function for array insertion at a given index
    void insertArray(int size);

    //function for deletion
    void deleteArray(int size);

    //function for linear search
    int linearSearch(int size);

    //function for binary search
    int binarySearch(int size);
};
#endif